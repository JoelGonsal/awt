const btn = document.getElementById("pressbtn");
const btn1 = document.getElementById("above500");

function loadjson(){

    const xhhr =  new XMLHttpRequest();

   xhhr.onreadystatechange = function() {

    if(this.readyState === 4 && this.status ==200)
    {
        const data = JSON.parse(this.responseText);

        let output = "";

        for(let i=0;i<data.length;i++)
        {
            output +=  `<tr>
                <td>${data[i].title}</td>
                <td>${data[i].price}</td>
                <td>${data[i].author}</td>
            </tr> 
            `;
        }
            document.getElementById("tablebody").innerHTML = output;

     

    }
   }

   xhhr.open("GET","books.json",true);
   xhhr.send();
}


function above(){
    
    const xhhrs = new XMLHttpRequest();

    xhhrs.onreadystatechange = function(){

        if(this.readyState== 4 && this.status==200)
        {

            const data1 = JSON.parse(this.responseText);

            let output = "";

            for(let i = 0; i< data1.length;i++)
            {
                console.log("Book",i);
                console.log(data1[i].title);
                console.log(data1[i].price);
                console.log(data1[i].author);

                if(data1[i].price > 500)
                {
                    output += `
                    <tr>
                    <td>${data1[i].title}</td>
                      <td>${data1[i].price}</td>
                        <td>${data1[i].author}</td>
                        </tr>
                    `;
                    
                }

            }
             document.getElementById("tablebody").innerHTML = output;



        }

    }




    xhhrs.open("GET","books.json",true);
    xhhrs.send();


}
btn.addEventListener("click",loadjson);
btn1.addEventListener("click",above);