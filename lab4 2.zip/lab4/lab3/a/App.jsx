import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import RegistrationForm from "./components/RegistrationForm";
import Register from "./components/register";


function App() {
  return (
    <div>
      <h1>Task 1 : Basic Form</h1>

      <Register/>
    </div>
  );
}

export default App;
