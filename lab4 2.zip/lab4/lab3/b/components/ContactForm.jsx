import { useState } from "react";
import "../Task2.css";


function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [topic, setTopic] = useState("General Inquiry");

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div>
      <h2>Contact Form</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Full Name"
          onChange={(e) => setName(e.target.value)}
        />
        <br />

        <input
          type="text"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />

        <textarea
          placeholder="Message"
          onChange={(e) => setMessage(e.target.value)}
        ></textarea>
        <br />

        <select onChange={(e) => setTopic(e.target.value)}>
          <option>General Inquiry</option>
          <option>Feedback</option>
          <option>Support</option>
        </select>
        <br />

        <button type="submit">Submit</button>
      </form>

      {submitted && (
        <div>
          <h3>Submitted Contact Details</h3>
          <p>Name: {name}</p>
          <p>Email: {email}</p>
          <p>Topic: {topic}</p>
          <p>Message: {message}</p>
        </div>
      )}
    </div>
  );
}

export default ContactForm;
