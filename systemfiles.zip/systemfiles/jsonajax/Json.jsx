import {useState,useEffect} from "react";

function Json(){

    const[data,setData] = useState([]);

    function loadjson(){

    const xhhr =  new XMLHttpRequest();

   xhhr.onreadystatechange = function() {

    if(this.readyState === 4 && this.status ==200)
    {
        setData(JSON.parse(this.responseText));

        

     

    }
   }

   xhhr.open("GET","/books.json",true);
   xhhr.send();
}
useEffect(() => {
        console.log("Data changed:", data);
    }, [data]);

    return(
        <>
            <h3>json Reading</h3>
            <button onClick={loadjson}>Load</button>

    <table border="2">
        <tr>
<th colSpan="3">Json Data/ XML Data</th>
        </tr>

<tr>
    <th>    temperature</th>
    <th>humidity</th>
    <th>condition</th>
</tr>
{
    data.map((item,index)=>{

        return(

            <tr key = {index}>
                <td>{item.title}</td>
                 <td>{item.price}</td>
                  <td>{item.author}</td>
            </tr>
        )

    })
}
    </table>
        </>
    )

}

export default Json;
