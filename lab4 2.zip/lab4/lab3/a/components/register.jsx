import { useState } from "react";

function Register() {

const [name,setName] = useState("");
const [email,setEmail] = useState("");
const [pass,setPass] = useState("");

const [finalname,setfinalName] = useState("");
const [submit, setSubmit] = useState(false);
const [submitted, setSubmitted] = useState(false);
const [error , SetError]= useState("");
const [emailerror , SetemError]= useState("");
const [passerror , SetpassError]= useState("");

const handleSubmit = (e)=>{
    e.preventDefault();

let valid = true;
setSubmitted(false);
SetError("");
SetemError("");
SetpassError("");

if(name === "")
{
SetError("eroor");
valid = false;
}

if(!email.includes("@"))
{
SetemError("eroor");
valid = false;
}

if(pass === "")
{
SetpassError("eroor");
valid = false;
}


if(valid)
{
    setSubmitted(true);
}
};

return(
    <div>

<form onSubmit={handleSubmit}>

<h1>Enter Name</h1>
<input placeholder="name" onChange={(e)=>setName(e.target.value)}
/>
 <p>{error}</p>

 <h1>Enter Email</h1>
<input placeholder="name" onChange={(e)=>setEmail(e.target.value)}
/>
 <p>{emailerror}</p>

 <h1>Enter Password</h1>
<input placeholder="name" onChange={(e)=>setPass(e.target.value)}
/>
 <p>{passerror}</p>

<button type="submit"> Submit </button>

{submitted &&(
    <div>
        <h1>{name}</h1>
         <h1>{email}</h1>
          <h1>{pass}</h1>
       
    </div>
)
}
</form>




    </div>
)

}

export default Register;