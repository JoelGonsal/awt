import fs from "node:fs";

fs.writeFileSync("demo.txt","hello");

//const data = fs.readFileSync("demo.txt",'utf-8');

//console.log(data);

const ndata = fs.readFile("demo.txt",'utf8',(err,ndata)=>{
    if(err)
    {
        throw err;
    }
    console.log(ndata);
})

fs.existsSync("demo.txt");

fs.appendFileSync("demo.txt","  this is continue")

