const fs = require("fs");

try {
  fs.writeFileSync("test.txt", "Hello Node JS");

  const data = fs.readFileSync("test.txt", "utf-8");

  console.log("File Content:", data);
} catch (err) {
  console.log("Error:", err);
} finally {
  console.log("Done");
}