import http from 'node:http';

const server = http.createServer((req,res)=>{
    res.write("hello from server");

    if(req.url === "/hello")
    {
        res.write("trial");
    }
    res.end();
})

server.listen(3000,()=>{
    console.log("visited");

});