import { useState, useEffect } from "react";

function Today(){

    const [name,setName] = useState("");
    const [tasks,setTasks] = useState([]);
    const [filter,setFilter] = useState("all");

    function addtask(){
if (name.trim() != ""){

    const newTask = {
title:name,
id : Date.now(),
completed:false
}

setTasks([...tasks,newTask])

}
;
    }

function deletetask(id){

    setTasks(tasks.filter((item)=>item.id!=id))
}

function changetoggle(id){
    setTasks(tasks.map((item)=>
    item.id == id ? {
        ...item, completed : !item.completed
    } : item ,))
}

const filtertasks = tasks.filter((item)=>
{
    if(filter=="all"){
        return true;
    }
    if(filter == "com")
    {
        return item.completed;
    }
    if(filter == "pen")
    {
        return !item.completed;
    }
})
return(
    <>
    <h1>Today Lists</h1>
    <input onChange={(e)=>setName(e.target.value)} ></input>
    <button onClick={addtask}>Add</button>
   <button onClick={()=>setFilter('all')}>all</button>
   <button onClick={()=>setFilter('com')}>completed</button>
   <button onClick={()=>setFilter('pen')}>pending</button>
{
    filtertasks.map((item)=>{
        return (
            <ul key = {item.id}>
                <li>
                    <span style = {{textDecoration:item.completed?"line-through":"none"}}>
                        {item.title}
                    </span>
                    <input
                    type="checkbox"
                    onClick={()=>changetoggle(item.id)}>
                    </input>
<button onClick={()=>deletetask(item.id)}>delete</button>
                
                </li>
            </ul>
        )
})
}
    
    </>
)

}
export default Today;