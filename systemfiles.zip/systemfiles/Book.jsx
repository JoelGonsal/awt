function Book({title , author , image })
{
    return(<>
    <h1>Book Name : {title}</h1>
    <h3>Author Name : {author} </h3>
    <img src = {image}></img>
    </>)

}

export default Book;