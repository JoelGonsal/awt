import { useState } from "react";

function Cart() {
    const [name, setName] = useState("");
    const [price, setPrice] = useState("");
    const [cart, setCart] = useState([]);

    // Add product
    function addProduct() {
        if (!name || !price) return;

        const newProduct = {
            name: name,
            price: Number(price),
            quantity: 1
        };

        setCart([...cart, newProduct]);

        setName("");
        setPrice("");
    }

    // Increase quantity
    function increase(index) {
        const updated = [...cart];
        updated[index].quantity += 1;
        setCart(updated);
    }

    // Decrease quantity
    function decrease(index) {
        const updated = [...cart];

        if (updated[index].quantity <= 1) return;

        updated[index].quantity -= 1;
        setCart(updated);
    }

    // Total price
    const total = cart.reduce((sum, item) => {
        return sum + item.price * item.quantity;
    }, 0);

    return (
        <>
            <h2>Cart System</h2>

            <input
                placeholder="Product name"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />

            <input
                placeholder="Price"
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
            />

            <button onClick={addProduct}>Add to Cart</button>

            <hr />

            <ul>
                {cart.map((item, index) => (
                    <li key={index}>
                        {item.name} - ₹{item.price} × {item.quantity}

                        <button onClick={() => increase(index)}>+</button>
                        <button onClick={() => decrease(index)}>-</button>
                    </li>
                ))}
            </ul>

            <h3>Total: ₹{total}</h3>
        </>
    );
}

export default Cart;