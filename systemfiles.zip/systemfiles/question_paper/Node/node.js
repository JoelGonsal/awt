import fs from "node:fs"

fs.writeFile("data.txt","AWT TEE EXAM",(err)=>{
    if(err) throw err;
}
)
let data1 = await fs.readFile("data.txt","utf8",(err,data)=>{

    if(err)throw err;
    
}
)

console.log(data1);