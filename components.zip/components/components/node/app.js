const mod = require("./mymodule");

try {
  console.log("Sum:", mod.add(5, 3));
} catch (err) {
  console.log("Error:", err);
} finally {
  console.log("Finished");
}