 function UserList(props){
    return(
        <>
        <h4>Employww List</h4>
        <ul>
            {props.employees.map((items,index)=>{
                return(
                <li>{items.name}</li>
                )

            })}
        </ul>

        </>
    )
 }

 export default UserList;