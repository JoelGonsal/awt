
import Welcome from './WelcomeMessage';
import Greetings from './Greetings';
import BookStore from './BookStore';
import RegistrationForm from './lab3/RegistrationForm';
import NewsLetter from './lab3/NewsLetter';
import ContactForm from './lab3/ContactForm';
import TodoApp from './lab4/TodoApp';
import TodoItem from './lab4/TodoItem';
import Shopping from './lab4/Shopping';
import Json from './jsonajax/Json';
import UserList from './questiona/UserList';
import Cart from './questiona/Cart';
import Today from './questiona/Today';
import UserForm from './questiona/userForm';
import DataEntry from './questiona/DataEntry';
import Home from './routing/home';

function App() {
  
 const employees = [
  {name:"joel"},
  {name:"deepali"},
  {name:"alka"}

  ];
  return (
<div>

  <Home></Home>
<DataEntry></DataEntry>
<UserForm></UserForm>
<Today></Today>
<Cart></Cart>
<UserList employees = {employees}></UserList>
 
  <ContactForm></ContactForm>
  <NewsLetter></NewsLetter>
  <RegistrationForm></RegistrationForm>
</div>
  )
}

export default App
