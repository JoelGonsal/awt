import mongoose from "mongoose";

mongoose.connect("mongodb://localhost:27017/newdbjoel").then(()=>{
    console.log("Create Succesffully");
    loadmongo();
})

const schema = new mongoose.Schema({
    name:String,
    age:Date
});

const res = new mongoose.model("name",schema);

async function loadmongo(){

    try{

        await res.create({
            name:"joel",
            age: new Date("2025-02-16")
        })

        var obj = [{
            name:"samay",
            age:24

        },{
            name:"mukeksh",
            age:25


        }]
        await res.insertMany(obj);


    

       const data = await res.find({ age: { $eq: 21 } });
       console.log(data);


    }

    
    
    catch{

    }
    finally{
        mongoose.connection.close();
    }
}