import React, {Component} from 'react';
import Book from "./Book";
import safe from "./assets/safe.png"

class BookStore extends Component{
    render()
    {
        return(
            <>
            <Book title = "Book 1" author ="Joel1" image = {safe}/>
            <Book title = "Book 2" author ="Joel2" image = {safe}/>
            <Book title = "Book 3" author ="Joel3" image = {safe}/>
            </>
        )

    }
}

export default BookStore;