const http = require("http");
const url = require("url");
const fs = require("fs");

http.createServer((req, res) => {
  try {
    const q = url.parse(req.url, true);
    const filename = q.query.file;

    if (!filename) throw "File name missing";

    fs.readFile(filename, (err, data) => {
      if (err) {
        res.write("File not found");
        return res.end();
      }

      res.write(data);
      res.end();
    });

  } catch (err) {
    res.write("Error: " + err);
    res.end();
  }
}).listen(3000);

console.log("Server running at http://localhost:3000");
//http://localhost:3000/?file=test.txt