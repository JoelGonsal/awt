import { useState } from "react";
import "../Task2.css";

function SubscriptionForm() {
  const [email, setEmail] = useState("");
  const [agree, setAgree] = useState(false);
  const [result, setResult] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (email !== "" && agree) {
      setResult("Subscription successful");
    } else {
      setResult("Please enter email and agree to terms");
    }
  };

  return (
    <div>
      <h2>Newsletter Subscription</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />

        <label>
          <input
            type="checkbox"
            onChange={(e) => setAgree(e.target.checked)}
          />
          Agree to terms and conditions
        </label>
        <br />

        <button type="submit">Subscribe</button>
      </form>

      <p>{result}</p>
    </div>
  );
}

export default SubscriptionForm;
