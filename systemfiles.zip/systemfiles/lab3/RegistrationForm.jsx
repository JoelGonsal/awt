import { useActionState, useState } from "react";

function RegistrationForm(){

const [name,setName]=useState("");
const [email,setEmail]=useState("");
const [password,setPass]=useState("");

const [nerror,NAerror]=useState("");
const [eerror,EAerror]=useState("");
const [perror,PAerror]=useState("");
let valid = true;
const[submitin,setSubmitted]=useState(false);


const handleSubmit = (e) => {
    e.preventDefault();
    
setSubmitted(false);
    NAerror(" ");
    EAerror(" ");
    PAerror(" ");

if(name.trim() == "")
{
    NAerror("Invalid");
    valid = false;
}

if(!email.includes("@") && !email.includes("."))
{
    EAerror("Invalid");
   valid = false;
}


if(password.length < 8)
{
    PAerror("Invalid");
valid = false;
}

if(valid)
{
    setSubmitted(true);
}




}




    return(
    <>
<h1>Registration Form</h1>
<form onSubmit={handleSubmit}>

    <h3>name</h3>
    <input onChange={(e)=>setName(e.target.value)} ></input>
    <p>{nerror}</p>

    <br></br>
    <h3>email</h3>
    <input onChange={(e)=>setEmail(e.target.value)} ></input>
     <p>{eerror}</p>

    <br></br>
    <h3>password</h3>
    <input  onChange={(e)=>setPass(e.target.value)} ></input>
     <p>{perror}</p>

<br></br>
    <button type = "submit">
        Submit
    </button>
{ submitin ? (
    <div>
    <h1>{name}</h1>
    <h1>{email}</h1>
    <h1>{password}</h1>
    </div>
    ) :null
}
</form>



    </>
    )
}

export default RegistrationForm;