function Greetings({name = "samay"}){
    return(
        <>
        <h1>Greetings : {name}</h1>
        </>
    )
}

export default Greetings;