import{BrowserRouter,Routes,Route,Link} from "react-router-dom";
import About from "./About";
import Error from "./error";
import Contact from "./Contact";


function Home(){
return(
    <>
      <BrowserRouter>
    <h1>hello</h1>
    <nav>
        <Link to = "/about">About</Link>
        <Link to = "/contact">contact</Link>
    </nav>
  
    <Routes>
        <Route path = "/about" element= {<About/>}/>
        <Route path = "/contact" element= {<Contact/>}/>
        <Route path = "/today" element= {<Today/>}/>
    </Routes>
    
    </BrowserRouter>
    </>
)
}

export default Home;