import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Greeting from "./components/Greeting";
import WelcomeMessage from "./components/WelcomeMessage";

function App() {
  return (
    <div>
      <WelcomeMessage name="idk" />
      <Greeting name="Joel Function Component1" />
      <Greeting name="Joel Function Component2" />
    </div>
  );
}

export default App;

