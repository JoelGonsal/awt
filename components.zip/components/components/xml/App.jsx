import { useState } from "react";

function App() {
  const [students, setStudents] = useState([]);

  function loadXML() {
    fetch("/data.xml")
      .then(res => res.text())
      .then(str => {
        const parser = new DOMParser();
        const xml = parser.parseFromString(str, "text/xml");

        const list = xml.getElementsByTagName("student");
        let data = [];

        for (let s of list) {
          data.push({
            id: s.getElementsByTagName("id")[0].textContent,
            name: s.getElementsByTagName("name")[0].textContent,
            age: s.getElementsByTagName("age")[0].textContent,
            class: s.getElementsByTagName("class")[0].textContent,
            city: s.getElementsByTagName("city")[0].textContent
          });
        }

        setStudents(data);
      });
  }

  return (
    <div>
      <h2>School Management (XML)</h2>

      <button onClick={loadXML}>Load Students</button>

      <table border="1">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Class</th>
          <th>City</th>
        </tr>

        {students.map((s, i) => (
          <tr key={i}>
            <td>{s.id}</td>
            <td>{s.name}</td>
            <td>{s.age}</td>
            <td>{s.class}</td>
            <td>{s.city}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default App;