import {useState} from "react";

function DataEntry(){

    const [data,setData]=useState([]);
    const [fdata,fsetData]=useState([]);
    const[xml,setXML]=useState([]);
     const[fxml,fsetXML]=useState([]);
    function loaddata(){
    const xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function(){

        if(this.readyState==4&&this.status==200){

            const res = JSON.parse(this.responseText);
        setData(JSON.parse(this.responseText));

        let arr=[];
        for(let i = 0;i<res.length;i++){
            if(res[i].price>200){
                arr.push(res[i]);
                
            }

        }
        fsetData(arr);

        }

    }

    xhttp.open("GET","data.json",true);
    xhttp.send();
    
}

function loadxml(){
const xhttps = new XMLHttpRequest();

    xhttps.onreadystatechange = function(){

        if(this.readyState==4&&this.status==200){

           const get = this.responseXML;
           const students = get.getElementsByTagName("student");

           let arr = [];

           for(let i = 0;i<students.length;i++){
            let name = students[i].getElementsByTagName("name")[0].textContent;
            let price = students[i].getElementsByTagName("price")[0].textContent;
            
            if(price>300){
               arr.push({
                name:name,
                price:Number(price)
            })
            }
            
            
           }

           fsetXML(arr);
           

        }
        

        }
xhttps.open("GET","data.xml",true);
    xhttps.send();
    }
    



return(
    <>
    <button onClick={loadxml}>Load</button>
    <table border = "1">
        <thead>
            <tr>
            <th>Name</th>
            <th>Price</th>
            </tr>
        </thead>

        {fxml.map((item,index)=>{
            return(
               <tbody key={index}>
                <tr>
                    <td>{item.name}</td>
                    <td>{item.price}</td>
                </tr>

               </tbody>
            )
        })}
    </table>
    </>
)
}

export default DataEntry;