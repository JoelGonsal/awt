const http = require("http");
const url = require("url");

http.createServer((req, res) => {
  try {
    const q = url.parse(req.url, true);
    const name = q.query.name;

    if (!name) throw "Name not provided";

    res.write("Hello " + name);
  } catch (err) {
    res.write("Error: " + err);
  } finally {
    res.end();
  }
}).listen(3000);

console.log("Server running at http://localhost:3000");

// http://localhost:3000/?name=John