import { useState } from "react";

function ShoppingList() {
  const [input, setInput] = useState("");
  const [items, setItems] = useState([]);

  const addItem = () => {
    if (!input.trim()) return;
    setItems([...items, input]);
    setInput("");
  };

  const deleteItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <div
      style={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#1e1e1e",
        color: "white",
      }}
    >
      <div style={{ textAlign: "center" }}>
        <h2>Joel's Shopping List</h2>

        <div style={{ marginBottom: "15px" }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            style={{
              padding: "6px",
              marginRight: "8px",
              backgroundColor: "#333",
              border: "1px solid #555",
              color: "white",
            }}
          />
          <button
            onClick={addItem}
            style={{
              padding: "6px 10px",
              backgroundColor: "#333",
              color: "white",
              border: "none",
              cursor: "pointer",
            }}
          >
            Add
          </button>
        </div>

        <ul style={{ paddingLeft: "20px" }}>
          {items.map((item, index) => (
            <li key={index} style={{ marginBottom: "8px" }}>
              {item}
              <button
                onClick={() => deleteItem(index)}
                style={{
                  marginLeft: "10px",
                  padding: "4px 8px",
                  backgroundColor: "#333",
                  color: "white",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default ShoppingList;
