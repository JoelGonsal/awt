import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import BookStore from './components/BookStore';

function App() {
  return (
    <div className="App">
      <header>
        <h1>Bookstore Application</h1>
      </header>
      <main>
        <BookStore />
      </main>
    </div>
  );
}

export default App;

