import sql from "mysql2";

const connection = sql.createConnection(
    {
   host: "localhost", // From the '@localhost' part
  user: "root",      // From the 'root' part
  password: "12345678",      // Usually empty on fresh Mac/Homebrew installs
  database: "nodejs"
    }
)

connection.connect((err)=>{
if(err)throw err;

console.log("connected");
})

const q1 = "insert into joel values(1,'myjoel')";

connection.query(q1,(err,result)=>{
if(err)throw err

console.log(result);
})

const q2 = "select * from joel";

connection.query(q2,(err,result)=>{
if(err)throw err

console.log(result);
})


