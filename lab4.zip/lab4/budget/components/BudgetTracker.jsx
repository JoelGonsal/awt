import React, { useState, useEffect } from "react";

function BudgetTracker() {
  const [transactions, setTransactions] = useState([]);
  const [text, setText] = useState("");
  const [amount, setAmount] = useState("");

  useEffect(() => {
    console.log("Transactions Updated:", transactions);
  }, [transactions]);

  const addTransaction = () => {
    if (!text || !amount) return;

    const newTransaction = {
      id: Date.now(),
      text,
      amount: parseFloat(amount),
    };

    setTransactions([...transactions, newTransaction]);
    setText("");
    setAmount("");
  };

  const total = transactions.reduce((acc, item) => acc + item.amount, 0);

  return (
    <div>
      <h2>Joel's Budget Tracker</h2>
      <input
        type="text"
        placeholder="Enter"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <br></br>
        <br></br>
      <input
        type="number"
        placeholder="Price"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <br></br>
        <br></br>
      <button onClick={addTransaction}>Add</button>

      <h3>Total: ₹{total}</h3>

      <ul>
        {transactions.map((t) => (
          <li key={t.id}>
            {t.text} : ₹{t.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BudgetTracker;

