import url from "node:url";
import http from "node:http";

const server = http.createServer((req, res) => {
  const myUrl = url.parse(req.url);

  res.write("Path: " + myUrl.pathname);
  res.write("Path: " + myUrl.query);
  res.end();
});

server.listen(3000);