import { useState } from "react";

function App() {
  const [students, setStudents] = useState([]);

  function loadData() {
    fetch("/data.json")
      .then(res => res.json())
      .then(data => setStudents(data.students));
  }

  return (
    <div>
      <h2>School Management System</h2>

      <button onClick={loadData}>Load Students</button>

      <table border="1">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Class</th>
          <th>City</th>
        </tr>

        {students.map((s) => (
          <tr key={s.id}>
            <td>{s.id}</td>
            <td>{s.name}</td>
            <td>{s.age}</td>
            <td>{s.class}</td>
            <td>{s.city}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default App;