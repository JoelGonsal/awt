import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import BudgetTracker from './components/BudgetTracker'

function App() {
  const [count, setCount] = useState(0)

  return (
    
      <BudgetTracker/>
  )
}

export default App
