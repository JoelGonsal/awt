import { useState } from "react";

function ContactForm(){


    const [name,setName] = useState("");
    const [topic,setTopic] = useState("");

    let valid = true;
    const[submitin,setSubmitted]=useState(false);


    const handleSubmit = (e) =>
    {
        e.preventDefault();

        setSubmitted(false);

        if(name == "")
        {
            valid = false;
        }

        if(topic == "")
        {
            valid = false;
        }
        if(valid)
{
    setSubmitted(true);
}


    }


    return(
        <>

<form onSubmit={handleSubmit}>

<h1>Full Name</h1>
<input onChange={(e)=>setName(e.target.value)} ></input>
<br></br>

<h1>Email</h1>
<input></input>
<br></br>

<h1>Message</h1>
<input></input>
<br></br>

<h1>Topic</h1>
<select onChange={(e)=>setTopic(e.target.value)}>
    <option>joel</option>
    <option>deepali</option>
    <option>chris</option>
</select>

<button type ="submit">submit</button>
<br></br>
{ submitin ? (
    <div>
    <h1>{name}</h1>
    <h1>{topic}</h1>
    </div>
    ) :null
}

</form>

        </>
    )

}

export default ContactForm;