import {useState} from "react";

function UserForm(){


const [user,setUser] = useState("");
const [email,setEmail] = useState("");
const [pass,setPass] = useState("");


function handlesubmit(e){

    e.preventDefault();


if(user.trim()=="")
{
    alert("invalid username");
    return;
}

const em = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

if(!em.test(email)){
    alert("invalid eMAIL");
    return;
}

const pasre = /^(?=.*[A-Z])(?=.*[!@#$%^&*]).{6,12}$/;

if(!pasre.test(pass)){
    alert("invalid Pass");
    return;
}

alert("sucess");


}
    return(
        <>
        <form onSubmit={handlesubmit}>
<h5>username:</h5>
<input onChange={(e)=>setUser(e.target.value)}></input>

<br></br>
<h5>email:</h5>
<input onChange={(e)=>setEmail(e.target.value)}></input>

<br></br>
<h5>password:</h5>
<input onChange={(e)=>setPass(e.target.value)}></input>

<button type="submit">Submit</button>
        </form>
        </>
    )
}

export default UserForm;