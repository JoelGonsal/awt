import { useState } from "react";


function NewsLetter()
{

    const[email,setEmail]=useState("");
    const[agree,setAgree]=useState(false);

    const[submitin,setSubmitted]=useState(false);


    const handleSubmit = (e) =>{
        e.preventDefault();
     let valid = true;
        setSubmitted(false);
        



        if(email == "")
        {
            valid = false;
        }

        if(agree === false)
        {
            valid = false;
        }

        if(valid)
        {
            setSubmitted(true);
        }
    }
    return(
        <>
        <form onSubmit={handleSubmit}>

<h3>Email : </h3>
<input  
onChange={(e)=> setEmail(e.target.value)}></input>

<br></br>
<h3>Checkbox : </h3>
<label> agree
<input type = "checkbox" 
onChange={(e)=> setAgree(e.target.value)}></input>
</label>


<br></br>
<button type ="submit">Submit</button>
 
 {
    submitin?(
        <div>
        <h1>{email}</h1>
        </div>
        
    ):null
 }


        </form>
        </>
    )
}

export default NewsLetter;