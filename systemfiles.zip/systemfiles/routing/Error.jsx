function Error(){
return(
    <>
    <h1>Hello Error</h1></>
)
}
export default Error;