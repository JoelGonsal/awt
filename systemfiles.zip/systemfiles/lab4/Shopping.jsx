import {useState, useEffect} from 'react';

function Shopping(){

    const[items,addItems] = useState([]);
    const[name,setName] = useState(" ");
    const[filter,setFilter] = useState("All");


    const addItem = () =>{

        const newItem = {
            id: Date.now(),
            text : name,
            purchased : false
        }

        addItems([...items,newItem]);
    }

    const toggle = (id) =>{

addItems(items.map((item)=> 
    item.id === id ? {...item,purchased : !item.purchased}:item 
)
) }


const deleteItem = (id) => {
    
    addItems(items.filter((item)=>item.id != id))
}

const filtered = items.filter((item)=>
{
    if(filter === "Purchased"){
        return item.purchased;
    }
    if(filter ==="Unpurchased"){
        return !item.purchased;
    }
    return true;
    }
)

    return(
        <>
        <h3>Shopping App</h3>
        <h5>Add Item : </h5>
        <input onChange={(e)=>setName(e.target.value)}/>

<button onClick={addItem}>Add Item</button>

<br></br>

<button onClick={()=>setFilter("All")}>All</button>
<button onClick={()=>setFilter("Purchased")}>Purchased</button>
<button onClick={()=>setFilter("Unpurchased")}>Unpurchased</button>

<ul>
{
    filtered.map((item)=>
    {
        return(
        
<li>
    <span style={{textDecoration : item.purchased ? "line-through":"none"}}>{item.text}</span>
    <input checked = {item.purchased} type = "checkbox" onChange={()=>toggle(item.id)}>
    </input>
    <button onClick={()=>{deleteItem(item.id)}}>Delete Item</button>
</li>

        )
    })
} 

</ul>

        </>
    )
   
}

export default Shopping;