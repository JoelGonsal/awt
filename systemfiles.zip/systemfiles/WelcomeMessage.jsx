import React, {Component} from 'react';

class WelcomeMessage extends Component{
render(){
    
    return(
    <div>
        <h1>Welcome : {this.props.name}</h1>
    </div>
    )
}
}

WelcomeMessage.defaultProps={
    name:"samay"
};

export default WelcomeMessage;