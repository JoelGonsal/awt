import { useState, useEffect } from "react";

function App() {

  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  const addTask = (e) => {
    e.preventDefault();

    if (task.trim() === "") return;

    const newTask = {
      id: Date.now(),
      text: task,
      completed: false
    };

    setTasks([...tasks, newTask]);
    setTask("");
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map(t =>
        t.id === id
          ? { ...t, completed: !t.completed }
          : t
      )
    );
  };

  useEffect(() => {
    console.log("Task list updated");
  }, [tasks]);

  return (
    <div style={{ textAlign: "center" }}>
      <h2>Simple TFVFVo-Do App</h2>

      <form onSubmit={addTask}>
        <input
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Enter task"
        />
        <button type="submit">Add</button>
      </form>

      <ul style={{ listStyle: "none" }}>
        {tasks.map((t) => (
          <li key={t.id} style={{ margin: "10px" }}>

            <input
              type="checkbox"
              checked={t.completed}
              onChange={() => toggleTask(t.id)}
            />

            <span
              style={{
                marginLeft: "10px",
                textDecoration: t.completed ? "line-through" : "none"
              }}
            >
              {t.text}
            </span>

            <button
              onClick={() => deleteTask(t.id)}
              style={{ marginLeft: "10px" }}
            >
              Delete
            </button>

          </li>
        ))}
      </ul>

    </div>
  );
}

export default App;
