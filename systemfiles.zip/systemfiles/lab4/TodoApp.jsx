import React, { useState, useEffect } from "react";

function TodoApp(){

  const [tasks,setTasks]= useState([]);
  const [task,TaskName]= useState("");
  const [get,FilterTasks] = useState("All");

const addTask = () =>
{
  const newTask =  
  {
      id : Date.now(),
      text : task,
      completed : false
    
  }
  
  setTasks([...tasks,newTask]);
}

const onDelete = (id)=>
{
setTasks(tasks.filter(((task)=>task.id !== id)))
}

const changeToggle = (id) =>
{
  setTasks(
    tasks.map((task)=> 
      task.id === id ? { ...task, completed : !
        task.completed }:task ,
),);
};

 const filteredTasks = tasks.filter((task) => {
    if (get=== "Completed") return task.completed;
    if (get === "Pending") return !task.completed;
    return true;
  });

  return(
    <>
    <h1>Todo App </h1>
    <h5>Enter Task</h5>
    <input onChange={(e)=>TaskName(e.target.value)}>
    </input>
    <button onClick={addTask}> Add Task </button>
    <br></br>

    <button onClick={()=>FilterTasks("All")}>All</button>
    <button onClick={()=>FilterTasks("Completed") }>Completed</button>
    <button onClick={()=>FilterTasks("Pending")} >Pending</button>
   
   <ul>
{filteredTasks.map((task) => {
      return (
        <li key={task.id}>
        <input type="checkbox"
        onChange={()=>changeToggle(task.id)}>
          
        </input>
<span style={{ textDecoration:task.completed ? "line-through":"none" }}>{task.text}</span>
        <button onClick={()=>{onDelete(task.id)}}>Delete</button>

        </li>
          
        
      );
    })}

    </ul>
    </>
  )
}





export default TodoApp;
