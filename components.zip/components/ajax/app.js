const tableBody = document.getElementById('table-body');

// JSON 
function loadJsonData() {
  var xhr = new XMLHttpRequest();

  xhr.open("GET", "data.json", true);

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      displayData(data);
    }
  };

  xhr.send();
}

// XML
function loadXmlData() {
  var xhr = new XMLHttpRequest();

  xhr.open("GET", "data.xml", true);

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {

      const xmlDoc = xhr.responseXML;
      const students = xmlDoc.getElementsByTagName("student");

      let dataArray = [];

      for (let i = 0; i < students.length; i++) {
        dataArray.push({
          Name: students[i].getElementsByTagName("name")[0].textContent,
          Age: students[i].getElementsByTagName("age")[0].textContent,
          City: students[i].getElementsByTagName("city")[0].textContent
        });
      }

      displayData(dataArray);
    }
  };

  xhr.send();
}

function displayData(data) {
  tableBody.innerHTML = "";

  const rows = data.map(item => `
    <tr>
      <td>${item.Name}</td>
      <td>${item.Age}</td>
      <td>${item.City}</td>
    </tr>
  `).join('');

  tableBody.innerHTML = rows;
}

document.getElementById('btn-json').addEventListener('click', loadJsonData);
document.getElementById('btn-xml').addEventListener('click', loadXmlData);