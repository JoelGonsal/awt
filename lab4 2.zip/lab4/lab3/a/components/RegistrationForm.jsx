import { useState } from "react";

function RegistrationForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    setNameError("");
    setEmailError("");
    setPasswordError("");
    setSubmitted(false);

    let valid = true;

    if (name === "") {
      setNameError("Username is required");
      valid = false;
    }

    if (email === "") {
      setEmailError("Email is required");
      valid = false;
    } 
    else if (!email.includes("@") || !email.includes(".")) {
      setEmailError("Enter a valid email address");
      valid = false;
    }

    if (password === "") {
      setPasswordError("Password is required");
      valid = false;
    } 
    else if (password.length < 8) {
      setPasswordError("Password must be at least 8 characters");
      valid = false;
    }

    if (valid) {
      setSubmitted(true);
    }
  };

  return (
    <div>
      <h2>Registration Form</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Username"
          onChange={(e) => setName(e.target.value)}
        />
        <p>{nameError}</p>

        <input
          type="text"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <p>{emailError}</p>

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />
        <p>{passwordError}</p>

        <button type="submit">Register</button>
      </form>

        {submitted &&(
        <div>
          <h3>Registered Successfully</h3>
          <p>Name: {name}</p>
          <p>Email: {email}</p>
        </div>
  )
      }
    </div>
  );
}

export default RegistrationForm;
